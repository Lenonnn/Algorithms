import React, { useState } from "react";
import "./styles.css";
import Box from "./Box";

export default function App() {
  const [countBoxes, setCountBoxes] = useState(0);

  const handleChangeBoxes = event => {
    setCountBoxes(+event.target.value);
  };

  //Fonte: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/from
  const array = Array.from({ length: countBoxes }, (v, i) => i);

  return (
    <div className="App">
      <h1>React Caixas</h1>
      <input
        type="number"
        placeholder="Quantidade de caixas"
        value={countBoxes}
        onChange={handleChangeBoxes}
        min="0"
        max="99"
        step="1"
      />

      <div style={{ marginTop: "20px", display: "flex", flexWrap: "wrap" }}>
        {array.map((item) => (
          <Box key={item}>{item + 1}</Box>
        ))}
      </div>
    </div>
  );
}
